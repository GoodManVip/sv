This folder is only for your OWN MyPet translation files!

The default translations are included into the plugin file itself.

If you are interested in translating MyPet visit:

https://translation.keyle.de/
